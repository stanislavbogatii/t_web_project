﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Laborator1_2.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Blocks()
        {
            return View();
        }
        public ActionResult Cards()
        {
            return View();
        }
        public ActionResult Carousels()
        {
            return View();
        }
        public ActionResult Forms()
        {
            return View();
        }
        public ActionResult People()
        {
            return View();
        }
        public ActionResult Pricing()
        {
            return View();
        }
    }
}